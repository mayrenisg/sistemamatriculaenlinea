--DATOS PARA TABLA DE ESCUELAS
EXECUTE usp_InsertarEscuelas @Id_Escuela = 'EID', @Nombre = 'Escuela de Innovaci�n Digital';

--DATOS DE PRUEBA PARA TABLA DE ESCUELAS
EXECUTE usp_InsertarEscuelas @Id_Escuela = 'EHT', @Nombre = 'Escuela de Hospitalidad y Turismo';
EXEC usp_ActualizarEscuelas @Id_Escuela = 'EHT', @Nombre = 'Escuela de Hospitalidad y Turismo Nacional';

SELECT * FROM Escuelas

EXEC usp_EliminarEscuelas 'EHT';

--DATOS PARA TABLA DE CARRERAS
EXECUTE usp_InsertarCarreras @Id_Carrera = 'DS', @Nombre = 'Desarrollo de Software', @Duracion_Cuatrimestres = 7, @Id_Escuela = 'EID';

--DATOS DE PRUEBA PARA TABLA DE CARRERAS
EXECUTE usp_InsertarCarreras @Id_Carrera = 'BD', @Nombre = 'Big Data y Ciencia de Datos', @Duracion_Cuatrimestres = 7, @Id_Escuela = 'EID';

EXEC usp_ActualizarCarreras @Id_Carrera = 'BD', @Nombre = 'Big Data', @Duracion_Cuatrimestres = 7, @Id_Escuela = 'EID';
EXEC usp_EliminarCarreras @Id_Carrera = 'BD';

SELECT * FROM Carreras

--DATOS DE PRUEBA PARA TABLA DE MATERIAS
EXEC usp_InsertarMaterias 101, 'Habilidades Digitales';
EXEC usp_InsertarMaterias 102, 'Redacci�n de Informes';
EXEC usp_InsertarMaterias 103, 'Ingl�s';
EXEC usp_InsertarMaterias 104, 'Taller de Matem�ticas';

EXEC usp_InsertarMaterias 1001, 'Sistemas operativos';
EXEC usp_InsertarMaterias 1002, 'Tecnolog�as de la informaci�n y comunicaci�n';
EXEC usp_InsertarMaterias 1003, 'Redes de computadoras';
EXEC usp_InsertarMaterias 1004, 'Introducci�n a ciberseguridad';
EXEC usp_InsertarMaterias 1005, 'Matem�ticas aplicadas';
EXEC usp_InsertarMaterias 2001, 'Comunicaci�n en ingl�s I';

EXEC usp_InsertarMaterias 1006, 'Programaci�n I';
EXEC usp_InsertarMaterias 1007, 'Matem�tica discreta';
EXEC usp_InsertarMaterias 1008, 'Base de Datos I';
EXEC usp_InsertarMaterias 1009, 'Desarrollo de interfaces de usuario';
EXEC usp_InsertarMaterias 3001, 'Deporte y Bienestar I'
EXEC usp_InsertarMaterias 3002, 'Geograf�a e historia de Panam�';
EXEC usp_InsertarMaterias 2002, 'Comunicaci�n en ingl�s II';

EXEC usp_InsertarMaterias 1011, 'Programaci�n II';
EXEC usp_InsertarMaterias 1012, 'Base de Datos II';
EXEC usp_InsertarMaterias 1013, 'An�lisis estad�stico I';
EXEC usp_InsertarMaterias 1014, 'Estructura de datos I';
EXEC usp_InsertarMaterias 1015, 'Desarrollo de aplicaciones web';
EXEC usp_InsertarMaterias 2003, 'Comunicaci�n en ingl�s III';

EXEC usp_InsertarMaterias 1016, 'Programaci�n III';
EXEC usp_InsertarMaterias 1017, 'Arquitectura de sistemas';
EXEC usp_InsertarMaterias 1018, 'Calidad de sistemas inform�ticos';
EXEC usp_InsertarMaterias 1019, 'Estructura de datos II';
EXEC usp_InsertarMaterias 1020, 'Electiva I';
EXEC usp_InsertarMaterias 2004, 'Comunicaci�n en ingl�s IV';

EXEC usp_InsertarMaterias 1021, 'Programaci�n IV';
EXEC usp_InsertarMaterias 1022, 'Gesti�n de proyectos digitales';
EXEC usp_InsertarMaterias 1023, 'Modelado y simulaci�n';
EXEC usp_InsertarMaterias 1024, 'Aplicaciones m�viles';
EXEC usp_InsertarMaterias 1025, 'Electiva II';
EXEC usp_InsertarMaterias 2005, 'Comunicaci�n en ingl�s V';

EXEC usp_InsertarMaterias 1026, 'Programaci�n V';
EXEC usp_InsertarMaterias 1027, '�tica profesional';
EXEC usp_InsertarMaterias 1028, 'Desarrollo y operaciones de TI';
EXEC usp_InsertarMaterias 1029, 'Auditor�a de sistemas';
EXEC usp_InsertarMaterias 1030, 'Mentor�a e inducci�n a proyectos I';
EXEC usp_InsertarMaterias 3003, 'Desarrollo personal y profesional';

EXEC usp_InsertarMaterias 1031, 'Mentor�a e inducci�n a proyectos II';
EXEC usp_InsertarMaterias 1032, 'Trabajo de graduaci�n';

SELECT * FROM Materias

--DATOS DE PRUEBA PARA TABLA DE MATERIAS
EXEC usp_InsertarMaterias 5, 'Programaci�n Orientada a Objetos'
EXEC usp_ActualizarMaterias 5, 'Programaci�n Orientada a Objetos - POO'
EXEC usp_EliminarMaterias 5

SELECT * FROM Materias WHERE Id_Materia=5

--DATOS PARA TABLA DE PLANES CURRICULARES
EXEC usp_InsertarPlanesCurriculares @Id_Carrera = 'DS', @Id_Materia = 101, @Cuatrimestre = 0;
EXEC usp_InsertarPlanesCurriculares @Id_Carrera = 'DS', @Id_Materia = 102, @Cuatrimestre = 0;
EXEC usp_InsertarPlanesCurriculares @Id_Carrera = 'DS', @Id_Materia = 103, @Cuatrimestre = 0;
EXEC usp_InsertarPlanesCurriculares @Id_Carrera = 'DS', @Id_Materia = 104, @Cuatrimestre = 0;

EXEC usp_InsertarPlanesCurriculares @Id_Carrera = 'DS', @Id_Materia = 1001, @Cuatrimestre = 1;
EXEC usp_InsertarPlanesCurriculares @Id_Carrera = 'DS', @Id_Materia = 1002, @Cuatrimestre = 1;
EXEC usp_InsertarPlanesCurriculares @Id_Carrera = 'DS', @Id_Materia = 1003, @Cuatrimestre = 1;
EXEC usp_InsertarPlanesCurriculares @Id_Carrera = 'DS', @Id_Materia = 1004, @Cuatrimestre = 1;
EXEC usp_InsertarPlanesCurriculares @Id_Carrera = 'DS', @Id_Materia = 1005, @Cuatrimestre = 1;
EXEC usp_InsertarPlanesCurriculares @Id_Carrera = 'DS', @Id_Materia = 2001, @Cuatrimestre = 1;

EXEC usp_InsertarPlanesCurriculares @Id_Carrera = 'DS', @Id_Materia = 1006, @Cuatrimestre = 2;
EXEC usp_InsertarPlanesCurriculares @Id_Carrera = 'DS', @Id_Materia = 1007, @Cuatrimestre = 2;
EXEC usp_InsertarPlanesCurriculares @Id_Carrera = 'DS', @Id_Materia = 1008, @Cuatrimestre = 2;
EXEC usp_InsertarPlanesCurriculares @Id_Carrera = 'DS', @Id_Materia = 1009, @Cuatrimestre = 2;
EXEC usp_InsertarPlanesCurriculares @Id_Carrera = 'DS', @Id_Materia = 3001, @Cuatrimestre = 2;
EXEC usp_InsertarPlanesCurriculares @Id_Carrera = 'DS', @Id_Materia = 2002, @Cuatrimestre = 2;

EXEC usp_InsertarPlanesCurriculares @Id_Carrera = 'DS', @Id_Materia = 1011, @Cuatrimestre = 3;
EXEC usp_InsertarPlanesCurriculares @Id_Carrera = 'DS', @Id_Materia = 1012, @Cuatrimestre = 3;
EXEC usp_InsertarPlanesCurriculares @Id_Carrera = 'DS', @Id_Materia = 1013, @Cuatrimestre = 3;
EXEC usp_InsertarPlanesCurriculares @Id_Carrera = 'DS', @Id_Materia = 1014, @Cuatrimestre = 3;
EXEC usp_InsertarPlanesCurriculares @Id_Carrera = 'DS', @Id_Materia = 1015, @Cuatrimestre = 3;
EXEC usp_InsertarPlanesCurriculares @Id_Carrera = 'DS', @Id_Materia = 2003, @Cuatrimestre = 3;

EXEC usp_InsertarPlanesCurriculares @Id_Carrera = 'DS', @Id_Materia = 1016, @Cuatrimestre = 4;
EXEC usp_InsertarPlanesCurriculares @Id_Carrera = 'DS', @Id_Materia = 1017, @Cuatrimestre = 4;
EXEC usp_InsertarPlanesCurriculares @Id_Carrera = 'DS', @Id_Materia = 1018, @Cuatrimestre = 4;
EXEC usp_InsertarPlanesCurriculares @Id_Carrera = 'DS', @Id_Materia = 1019, @Cuatrimestre = 4;
EXEC usp_InsertarPlanesCurriculares @Id_Carrera = 'DS', @Id_Materia = 1020, @Cuatrimestre = 4;
EXEC usp_InsertarPlanesCurriculares @Id_Carrera = 'DS', @Id_Materia = 2004, @Cuatrimestre = 4;

EXEC usp_InsertarPlanesCurriculares @Id_Carrera = 'DS', @Id_Materia = 1021, @Cuatrimestre = 5;
EXEC usp_InsertarPlanesCurriculares @Id_Carrera = 'DS', @Id_Materia = 1022, @Cuatrimestre = 5;
EXEC usp_InsertarPlanesCurriculares @Id_Carrera = 'DS', @Id_Materia = 1023, @Cuatrimestre = 5;
EXEC usp_InsertarPlanesCurriculares @Id_Carrera = 'DS', @Id_Materia = 1024, @Cuatrimestre = 5;
EXEC usp_InsertarPlanesCurriculares @Id_Carrera = 'DS', @Id_Materia = 1025, @Cuatrimestre = 5;
EXEC usp_InsertarPlanesCurriculares @Id_Carrera = 'DS', @Id_Materia = 2005, @Cuatrimestre = 5;

EXEC usp_InsertarPlanesCurriculares @Id_Carrera = 'DS', @Id_Materia = 1026, @Cuatrimestre = 6;
EXEC usp_InsertarPlanesCurriculares @Id_Carrera = 'DS', @Id_Materia = 1027, @Cuatrimestre = 6;
EXEC usp_InsertarPlanesCurriculares @Id_Carrera = 'DS', @Id_Materia = 1028, @Cuatrimestre = 6;
EXEC usp_InsertarPlanesCurriculares @Id_Carrera = 'DS', @Id_Materia = 1029, @Cuatrimestre = 6;
EXEC usp_InsertarPlanesCurriculares @Id_Carrera = 'DS', @Id_Materia = 1030, @Cuatrimestre = 6;
EXEC usp_InsertarPlanesCurriculares @Id_Carrera = 'DS', @Id_Materia = 3003, @Cuatrimestre = 6;

EXEC usp_InsertarPlanesCurriculares @Id_Carrera = 'DS', @Id_Materia = 1031, @Cuatrimestre = 7;
EXEC usp_InsertarPlanesCurriculares @Id_Carrera = 'DS', @Id_Materia = 1032, @Cuatrimestre = 7;

SELECT * FROM Planes_Curriculares

--DATOS DE PRUEBA PARA TABLA DE PLANES CURRICULARES

EXEC usp_InsertarPlanesCurriculares
    @Id_Carrera = 'DS', 
    @Id_Materia = 1001, 
    @Cuatrimestre = 10;
GO

--SELECT * FROM Planes_Curriculares where Id_Curricular=43

EXEC usp_ActualizarPlanesCurriculares
    @Id_Curricular = 43,
    @Id_Carrera = 'DS',
    @Id_Materia = 1001,
    @Cuatrimestre = 9;
GO

EXEC usp_EliminarPlanesCurriculares 43

SELECT * FROM Estudiantes
--DATOS PARA TABLA DE ESTUDIANTES
EXEC usp_InsertEstudiante 
    @Nombre1 = 'Mayrenis', 
    @Nombre2 = 'Solangel', 
    @Apellido1 = 'G�mez', 
    @Apellido2 = 'C�ceres', 
    @Cedula = '8493833', 
    @Fecha_Nacimiento = '2004-05-02', 
    @Direccion = 'Calle 6ta Este', 
    @Id_Carrera = 'DS'

EXEC usp_InsertEstudiante 
    @Nombre1 = 'Juan', 
    @Nombre2 = 'Carlos', 
    @Apellido1 = 'Mart�nez', 
    @Apellido2 = 'P�rez', 
    @Cedula = '9374923', 
    @Fecha_Nacimiento = '2003-09-15', 
    @Direccion = 'Calle 1era Ave', 
    @Id_Carrera = 'DS'

EXEC usp_InsertEstudiante 
    @Nombre1 = 'Ana', 
    @Nombre2 = 'Isabel', 
    @Apellido1 = 'Lopez', 
    @Apellido2 = 'Mendoza', 
    @Cedula = 'E39572432', 
    @Fecha_Nacimiento = '2002-12-10', 
    @Direccion = 'Avenida 3ra Oeste', 
    @Id_Carrera = 'DS'
    
EXEC usp_InsertEstudiante 
    @Nombre1 = 'Pedro', 
    @Nombre2 = 'Antonio', 
    @Apellido1 = 'Ram�rez', 
    @Apellido2 = 'D�az', 
    @Cedula = 'P589483', 
    @Fecha_Nacimiento = '2001-06-25', 
    @Direccion = 'Calle 2da Este', 
    @Id_Carrera = 'DS'

EXEC usp_InsertEstudiante 
    @Nombre1 = 'Sof�a', 
    @Nombre2 = 'Isabel', 
    @Apellido1 = 'Gonz�lez', 
    @Apellido2 = 'Castillo', 
    @Cedula = '3458334', 
    @Fecha_Nacimiento = '2003-03-18', 
    @Direccion = 'Calle 4ta Norte', 
    @Id_Carrera = 'DS'

EXEC usp_InsertEstudiante 
    @Nombre1 = 'Carlos', 
    @Nombre2 = 'Eduardo', 
    @Apellido1 = 'Fern�ndez', 
    @Apellido2 = 'Ruiz', 
    @Cedula = 'P482442', 
    @Fecha_Nacimiento = '2000-11-02', 
    @Direccion = 'Calle 5ta Sur', 
    @Id_Carrera = 'DS'

EXEC usp_InsertEstudiante 
    @Nombre1 = 'Laura', 
    @Nombre2 = 'Paola', 
    @Apellido1 = 'S�nchez', 
    @Apellido2 = 'Mart�nez', 
    @Cedula = '98247324', 
    @Fecha_Nacimiento = '2002-07-22', 
    @Direccion = 'Calle 7ma Oeste', 
    @Id_Carrera = 'DS'

EXEC usp_InsertEstudiante 
    @Nombre1 = 'Jos�', 
    @Nombre2 = 'Antonio', 
    @Apellido1 = 'P�rez', 
    @Apellido2 = 'L�pez', 
    @Cedula = '7164723', 
    @Fecha_Nacimiento = '2001-10-14', 
    @Direccion = 'Avenida 8va Sur', 
    @Id_Carrera = 'DS'

EXEC usp_InsertEstudiante 
    @Nombre1 = 'Mar�a', 
    @Nombre2 = 'Jos�', 
    @Apellido1 = 'Mart�nez', 
    @Apellido2 = 'Jim�nez', 
    @Cedula = '1434433', 
    @Fecha_Nacimiento = '2000-05-30', 
    @Direccion = 'Calle 9na Este', 
    @Id_Carrera = 'DS'

EXEC usp_InsertEstudiante 
    @Nombre1 = 'Miguel', 
    @Nombre2 = '�ngel', 
    @Apellido1 = 'Rodr�guez', 
    @Apellido2 = 'Garc�a', 
    @Cedula = '81008533', 
    @Fecha_Nacimiento = '2002-01-13', 
    @Direccion = 'Calle 10ma Norte', 
    @Id_Carrera = 'DS'

SELECT * FROM Estudiantes

--DATOS DE PRUEBA PARA TABLA DE ESTUDIANTES
EXEC usp_InsertEstudiante 
    @Nombre1 = 'Lil', 
    @Nombre2 = 'Cristiana', 
    @Apellido1 = 'Torres', 
    @Apellido2 = 'Garrido', 
    @Cedula = '847524', 
    @Fecha_Nacimiento = '1954-05-02', 
    @Direccion = 'Calle 42 Este, Panam�', 
    @Id_Carrera = 'DS'

EXECUTE usp_UpdateEstudiante 11, 'Lil','Cristiana', 'Torres', 'Garrido', 'Calle 25 R�o Abajo', 'DS', 'A'

EXECUTE usp_EliminarEstudiante 11

SELECT * FROM Estudiantes where Id_Estudiante=11


--DATOS PARA TABLA DE MATRICULA
--SE DEBE ACTIVAR EL TRIGGER DE trg_InsertProgreso para que autom�ticamente cuando se matricule materia, se registre progreso

SELECT * FROM Escuelas
SELECT * FROM Materias
SELECT * FROM Planes_Curriculares
SELECT * FROM Estudiantes
SELECT * FROM Carreras

SELECT * FROM Progreso_Estudiantes
SELECT * FROM Matriculas

UPDATE Estudiantes
SET correo = 'mayrenis@itse.ac.pa', contrasena = 'NuevaContrase�aAleatoria'
WHERE Id_Estudiante = 20;


EXEC usp_InsertarMatriculas 1, 101;
EXEC usp_InsertarMatriculas 1, 102;
EXEC usp_InsertarMatriculas 1, 103;
EXEC usp_InsertarMatriculas 1, 104;

EXEC usp_InsertarMatriculas 3, 101;
EXEC usp_InsertarMatriculas 3, 102;
EXEC usp_InsertarMatriculas 3, 103;
EXEC usp_InsertarMatriculas 3, 104;

EXEC usp_InsertarMatriculas 4, 101;
EXEC usp_InsertarMatriculas 4, 102;
EXEC usp_InsertarMatriculas 4, 103;
EXEC usp_InsertarMatriculas 4, 104;

EXEC usp_InsertarMatriculas 4, 1002;
EXEC usp_InsertarMatriculas 4, 1003;
EXEC usp_InsertarMatriculas 4, 1004;
EXEC usp_InsertarMatriculas 4, 1005;
EXEC usp_InsertarMatriculas 4, 2001;

--SE DEBEN PONER LA CALIFICACI�N EN CADA MATRICULA, ESPECIFICAMENTE PONER LA CALIFICACION EN PROGRESO ESTUDIANTIL

SELECT * FROM Matriculas
SELECT * FROM Progreso_Estudiantes

--DATOS DE PRUEBA PARA TABLA DE MATRICULA
EXEC usp_InsertarMatriculas 10, 101
SELECT * FROM Matriculas WHERE Id_Estudiante=10

EXEC usp_ActualizarMatriculas 18, 10, 102

EXEC usp_EliminarMatr�culas 18
SELECT * FROM Matriculas WHERE Id_Matricula=48


--DATOS DE PRUEBA PARA TABLA DE  PROGRESO ESTUDIANTES
EXEC usp_InsertarProgresoEstudiante
    @Id_Estudiante = 10,
    @Cuatrimestre = 0,
    @Id_Materia = 101,
    @Calificacion = 85;
GO

SELECT * FROM Progreso_Estudiantes

EXEC usp_ActualizarProgresoEstudiante 2, 0, 102, 75

DISABLE TRIGGER trg_agregarEstado ON Progreso_Estudiantes;

EXEC usp_EliminarProgresoEstudiante @IdProgreso = 2;


--PRUEBA DE PROCEDIMIENTO CON CURSOR Y FUNCI�N AGREGADA
SELECT * FROM ESTUDIANTES

usp_CrearCorreoContrasena 

UPDATE Estudiantes
SET correo = NULL, CONTRASENA = NULL
WHERE Id_Estudiante BETWEEN 23 AND 40;

EXECUTE MateriasMatricular 40

--PRUEBA DE PROCEDIMIENTO CON CURSOR Y FUNCI�N AGREGADA
SELECT * FROM ESTUDIANTES

usp_CrearCorreoContrasena 

UPDATE Estudiantes
SET correo = NULL, CONTRASENA = NULL
WHERE Id_Estudiante BETWEEN 23 AND 40;

EXECUTE MateriasMatricular 1

SELECT * FROM Progreso_Estudiantes
 