CREATE TABLE Periodos_Academicos (
    Id_Periodo INT PRIMARY KEY,                         
    Anio INT NOT NULL,                                  
    Numero_Periodo TINYINT NOT NULL CHECK (numero_periodo IN (1,2,3)),
	Inicio_Periodo DATE NOT NULL,
    Fin_Periodo DATE NOT NULL,
    Inicio_Clases DATE NOT NULL,
    Fin_Clases DATE NOT NULL,
    Inicio_Matricula DATE NOT NULL,
    Fin_Matricula DATE NOT NULL
);

SELECT * FROM Periodos_Academicos

-- Periodo 1 - 2023
INSERT INTO Periodos_Academicos VALUES (
    12023, 2023, 1,
    '2023-01-01', '2023-04-30',
    '2023-01-16', '2023-04-22',
    '2023-01-11', '2023-01-14'
);

-- Periodo 2 - 2023
INSERT INTO Periodos_Academicos VALUES (
    22023, 2023, 2,
    '2023-05-01', '2023-08-31',
    '2023-05-15', '2023-08-12',
    '2023-05-08', '2023-05-13'
);

-- Periodo 3 - 2023
INSERT INTO Periodos_Academicos VALUES (
    32023, 2023, 3,
    '2023-09-01', '2023-12-31',
    '2023-09-04', '2023-12-02',
    '2023-08-28', '2023-09-02'
);

-- Periodo 1 - 2024
INSERT INTO Periodos_Academicos VALUES (
    12024, 2024, 1,
    '2024-01-01', '2024-04-30',
    '2024-01-29', '2024-04-19',
    '2024-01-22', '2024-01-26'
);

-- Periodo 2 - 2024
INSERT INTO Periodos_Academicos VALUES (
    22024, 2024, 2,
    '2024-05-01', '2024-08-31',
    '2024-05-06', '2024-07-26',
    '2024-04-29', '2024-05-03'
);

-- Periodo 3 - 2024
INSERT INTO Periodos_Academicos VALUES (
    32024, 2024, 3,
    '2024-09-01', '2024-12-31',
    '2024-09-02', '2024-11-22',
    '2024-08-26', '2024-08-30'
);

-- Periodo 1 - 2025
INSERT INTO Periodos_Academicos VALUES (
    12025, 2025, 1,
    '2025-01-01', '2025-04-30',
    '2025-01-13', '2025-04-12',
    '2025-01-06', '2025-01-11'
);

-- Periodo 2 - 2025
INSERT INTO Periodos_Academicos VALUES (
    22025, 2025, 2,
    '2025-05-01', '2025-08-31',
    '2025-05-12', '2025-08-09',
    '2025-05-05', '2025-05-10'
);

-- Periodo 3 - 2025
INSERT INTO Periodos_Academicos VALUES (
    32025, 2025, 3,
    '2025-09-01', '2025-12-31',
    '2025-09-08', '2025-12-06',
    '2025-09-01', '2025-09-06'
);

SELECT 
    CASE 
        WHEN GETDATE() BETWEEN Inicio_Matricula AND Fin_Matricula THEN 'Periodo de Matr�cula'
        WHEN GETDATE() BETWEEN Inicio_Clases AND Fin_Clases THEN 'Periodo de Clases'
        ELSE 'Otro Periodo, Ni Matr�cula Ni Clases'
    END AS Periodo_Actual
FROM Periodos_Academicos
WHERE GETDATE() BETWEEN Inicio_Periodo AND Fin_Periodo;

SELECT * FROM Periodos_Academicos

SELECT 
    CASE 
        WHEN '2025-01-10' BETWEEN Inicio_Matricula AND Fin_Matricula THEN 'Periodo de Matr�cula'
        WHEN '2025-01-10' BETWEEN Inicio_Clases AND Fin_Clases THEN 'Periodo de Clases'
        ELSE 'Otro Periodo, Ni Matr�cula Ni Clases'
    END AS Periodo_Actual
FROM Periodos_Academicos
WHERE '2025-01-10' BETWEEN Inicio_Periodo AND Fin_Periodo;

SELECT * FROM Periodos_Academicos


SELECT Anio, Numero_Periodo  
FROM Periodos_Academicos 
WHERE '2023-11-12' BETWEEN Inicio_Periodo AND Fin_Periodo;