--======================================================================================
--Author: Mayrenis G�mez
--Create date: 08-12-2024
--Description: Creaci�n de Base de Datos y Tablas
--=======================================================================================

CREATE DATABASE Sistema_Matricula
USE Sistema_Matricula

--=======================================================================================
--1. TABLA DE ESCUELAS
CREATE TABLE Escuelas (
  Id_Escuela varchar(10) NOT NULL PRIMARY KEY,
  Nombre varchar(150) NOT NULL,
);

SELECT * FROM Escuelas
--=======================================================================================
--2. TABLA DE CARRERAS
CREATE TABLE Carreras (
  Id_Carrera varchar(5) NOT NULL PRIMARY KEY,
  Nombre varchar(35) NOT NULL,
  Duracion_Cuatrimestres int NOT NULL,
  Id_Escuela varchar(10) NOT NULL
);
ALTER TABLE Carreras ADD CONSTRAINT Carreras_Id_Escuela_fk FOREIGN KEY (Id_Escuela) REFERENCES Escuelas (Id_Escuela);
SELECT * FROM Carreras

--=======================================================================================
--3. TABLA DE MATERIAS 
CREATE TABLE Materias (
  Id_Materia int NOT NULL PRIMARY KEY,
  Nombre varchar(200) NOT NULL,
  Nota_Aprobacion int NOT NULL DEFAULT 71
 );
 SELECT * FROM Materias

 --=======================================================================================
--4. TABLA DE PLANES CURRICULARES
 CREATE TABLE Planes_Curriculares (
  Id_Curricular int NOT NULL PRIMARY KEY IDENTITY(1,1),
  Id_Carrera varchar(5) NOT NULL,
  Id_Materia int NOT NULL,
  Cuatrimestre int NOT NULL
);
ALTER TABLE Planes_Curriculares ADD CONSTRAINT Planes_Curriculares_Id_Materia_fk FOREIGN KEY (Id_Materia) REFERENCES Materias (Id_Materia);
ALTER TABLE Planes_Curriculares ADD CONSTRAINT Planes_Curriculares_Id_Carrera_fk FOREIGN KEY (Id_Carrera) REFERENCES Carreras (Id_Carrera);

 SELECT * FROM Planes_Curriculares

--=======================================================================================
--5. TABLA DE ESTUDIANTES
CREATE TABLE Estudiantes (
  Id_Estudiante int NOT NULL PRIMARY KEY IDENTITY(1,1),
  Nombre1 varchar(35) NOT NULL,
  Nombre2  varchar(35) NULL,
  Apellido1  varchar(35) NOT NULL,
  Apellido2  varchar(35) NULL,
  Cedula varchar(30) UNIQUE NOT NULL,
  Fecha_Nacimiento date NOT NULL,
  Direccion  varchar(100) NOT NULL,
  Id_Carrera varchar(5) NOT NULL,
  Fecha_Registro date NOT NULL DEFAULT GETDATE(),
  Estado char NOT NULL DEFAULT 'A', -- A=activo, I=inactivo, g= graduado
  Correo varchar(100) NULL,
  Contrasena varchar(100) NULL
);

ALTER TABLE Estudiantes ADD CONSTRAINT Estudiantes_Id_Carrera_fk FOREIGN KEY (Id_Carrera) REFERENCES Carreras (Id_Carrera);
SELECT * FROM Estudiantes
--=======================================================================================
--6. TABLA DE PROGRESO DE ESTUDIANTES
CREATE TABLE Progreso_Estudiantes (
  Id_Progreso int NOT NULL PRIMARY KEY IDENTITY(1,1),
  Id_Estudiante int NOT NULL,
  Cuatrimestre int NOT NULL,
  Id_Materia int NOT NULL,
  Estado char NULL, -- 'A' Aprobado, 'D' Desaprobado, 'I' Incompleto
  Calificacion int NULL CHECK (Calificacion >= 0 AND Calificacion <= 100),
);
ALTER TABLE Progreso_Estudiantes ADD CONSTRAINT Progreso_Estudiantes_Id_Materia_fk FOREIGN KEY (Id_Materia) REFERENCES Materias (Id_Materia);
ALTER TABLE Progreso_Estudiantes ADD CONSTRAINT Progreso_Estudiantes_Id_Estudiante_fk FOREIGN KEY (Id_Estudiante) REFERENCES Estudiantes (Id_Estudiante);

SELECT * FROM Progreso_Estudiantes

 --=======================================================================================
--7. TABLA DE MATR�CULAS 
 CREATE TABLE Matriculas (
  Id_Matricula int NOT NULL PRIMARY KEY IDENTITY(1,1),
  Id_Estudiante int NOT NULL,
  Id_Materia int NOT NULL,
  Fecha_Matricula date NOT NULL DEFAULT GETDATE()
);

ALTER TABLE Matriculas ADD CONSTRAINT Matriculas_Id_Estudiante_fk FOREIGN KEY (Id_Estudiante) REFERENCES Estudiantes (Id_Estudiante);
ALTER TABLE Matriculas ADD CONSTRAINT Matriculas_Id_Materia_fk FOREIGN KEY (Id_Materia) REFERENCES Materias (Id_Materia);

