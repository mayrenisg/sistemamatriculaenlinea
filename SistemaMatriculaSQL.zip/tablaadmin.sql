CREATE TABLE Administradores (
    Id_Admin INT IDENTITY(1,1) PRIMARY KEY,
    Correo VARCHAR(255) NOT NULL,
    Contrasena VARCHAR(255) NOT NULL
);

INSERT INTO Administradores (correo, contrasena)  
VALUES ('admin1@itse.ac.pa', 'admin1itse');

SELECT * FROM Administradores