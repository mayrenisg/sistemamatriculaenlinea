--======================================================================================
--Authors: Angie De Gracia, Dorothy Dyer, Jos� Trejos y Mayrenis G�mez
--Create date: 08-12-2024
--Description: Creaci�n de Tabla Bit�cora y Trigger para Diferentes Tablas.
--=======================================================================================

--1. PROCEDIMIENTOS PARA TABLA DE ESCUELAS

CREATE OR ALTER PROC usp_InsertarEscuelas @Id_Escuela varchar(10),
										  @Nombre varchar(35)
	AS
		BEGIN
		 SET NOCOUNT ON;
		 BEGIN TRY
		  IF EXISTS (SELECT 1 FROM Escuelas WHERE Id_Escuela = @Id_Escuela)
            BEGIN
				RAISERROR ('Ya existe una Escuela con el mismo ID.', 11,1);
				RETURN;
			END
			INSERT INTO Escuelas(Id_Escuela, Nombre)
			VALUES (@Id_Escuela, @Nombre);
			PRINT ('La escuela se ha insertado correctamente.');
		END TRY
		BEGIN CATCH
			PRINT 'Ocurri� un error al insertar la escuela.';
			PRINT ERROR_MESSAGE();
		END CATCH
	END;
	GO


CREATE OR ALTER PROC usp_ActualizarEscuelas @Id_Escuela varchar(10),
											@Nombre varchar(100)
	AS
BEGIN
    SET NOCOUNT ON; 

    BEGIN TRY
        IF NOT EXISTS (SELECT 1 FROM Escuelas WHERE Id_Escuela = @Id_Escuela)
        BEGIN
            RAISERROR ('No se encontr� una carrera con el ID especificado.',11,1);
            RETURN;
        END

        UPDATE Escuelas
        SET
            Nombre = @Nombre
        WHERE Id_Escuela = @Id_Escuela;
        PRINT 'La carrera se ha actualizado correctamente.';
    END TRY
    BEGIN CATCH
        PRINT 'Ocurri� un error al actualizar la carrera.';
    END CATCH
END;
GO

--Procedimiento almacenado para Delete en tabla Escuelas

CREATE OR ALTER PROC usp_EliminarEscuelas
    @Id_Escuela varchar(5)
AS
BEGIN
    BEGIN TRY
		BEGIN TRANSACTION;

		--Verificar que el registro existe en la tabla Escuelas
        IF NOT EXISTS (SELECT 1 FROM Escuelas WHERE Id_Escuela = @Id_Escuela)
        BEGIN
            RAISERROR ('No se encontr� una Escuela con el ID especificado.', 16, 1);
			ROLLBACK TRANSACTION;
            RETURN;
        END
		
		--Eliminar el registro de la tabla Escuelas
        DELETE FROM Escuelas
        WHERE Id_Escuela = @Id_Escuela;

		--Confirmar la transacci�n
		COMMIT TRANSACTION;


        PRINT 'La escuela se ha eliminado correctamente.';
    END TRY
    BEGIN CATCH
		--Si ocurre un error, deshacer la transacci�n
		ROLLBACK TRANSACTION;

        --Capturar el error y mostrarlo
		DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;

		SELECT @ErrorMessage = Error_Message(),
			   @ErrorSeverity = Error_Severity(),
			   @ErrorState = Error_State();

		RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END CATCH
END;
GO

--=======================================================================================
--2. PROCEDIMIENTOS PARA TABLA DE CARRERAS
--INSERT
CREATE OR ALTER PROC usp_InsertarCarreras @Id_Carrera varchar(5),
												   @Nombre varchar(35),
												   @Duracion_Cuatrimestres int,
												   @Id_Escuela varchar(10)
	AS
		BEGIN
		 SET NOCOUNT ON;
		 BEGIN TRY
		  IF EXISTS (SELECT 1 FROM Carreras WHERE Id_Carrera = @Id_Carrera)
            BEGIN
				RAISERROR ('Ya existe una carrera con el mismo ID.',7,1);
				RETURN;
			END

			INSERT INTO Carreras(Id_Carrera, Nombre, Duracion_Cuatrimestres, Id_Escuela)
			VALUES (@Id_Carrera, @Nombre, @Duracion_Cuatrimestres, @Id_Escuela);
			PRINT ('La carrera se ha insertado correctamente.');
		END TRY
		BEGIN CATCH
			PRINT 'Ocurri� un error al insertar la carrera.';
			PRINT ERROR_MESSAGE();
		END CATCH
	END;
	GO

--UPDATE
CREATE OR ALTER PROC usp_ActualizarCarreras @Id_Carrera varchar(5),
												   @Nombre varchar(35),
												   @Duracion_Cuatrimestres int,
												   @Id_Escuela varchar(10)
	AS
BEGIN
    SET NOCOUNT ON; 

    BEGIN TRY
        IF NOT EXISTS (SELECT 1 FROM Carreras WHERE Id_Carrera = @Id_Carrera)
        BEGIN
            RAISERROR ('No se encontr� una carrera con el ID especificado.', 7, 1);
            RETURN;
        END

        UPDATE Carreras
        SET
            Nombre = @Nombre,
            Duracion_Cuatrimestres = @Duracion_Cuatrimestres,
            Id_Escuela = @Id_Escuela
        WHERE Id_Carrera = @Id_Carrera;

        PRINT 'La carrera se ha actualizado correctamente.';
    END TRY
    BEGIN CATCH
        PRINT 'Ocurri� un error al actualizar la carrera.';
    END CATCH
END;
GO


--DELETE
CREATE OR ALTER PROC usp_EliminarCarreras
    @Id_Carrera varchar(5)
AS
BEGIN
    SET NOCOUNT ON; 

    BEGIN TRY
        IF NOT EXISTS (SELECT 1 FROM Carreras WHERE Id_Carrera = @Id_Carrera)
        BEGIN
            RAISERROR ('No se encontr� una carrera con el ID especificado.', 7, 1);
            RETURN;
        END

        DELETE FROM Carreras
        WHERE Id_Carrera = @Id_Carrera;

        -- Mensaje de �xito
        PRINT 'La carrera se ha eliminado correctamente.';
    END TRY
    BEGIN CATCH
        PRINT 'Ocurri� un error al intentar eliminar la carrera.';
    END CATCH
END;
GO

--=======================================================================================
--3. PROCEDIMIENTOS PARA TABLA DE MATERIAS
CREATE OR ALTER PROC usp_InsertarMaterias @Id_Materia int,
										  @Nombre varchar(100)
	AS
		BEGIN
		 SET NOCOUNT ON;
		 BEGIN TRY
		  IF EXISTS (SELECT 1 FROM Materias WHERE Id_Materia = @Id_Materia)
            BEGIN
				RAISERROR ('Ya existe una Materia con el mismo ID.', 11,1);
				RETURN;
			END
			INSERT INTO Materias(Id_Materia, Nombre)
			VALUES (@Id_Materia, @Nombre);
			PRINT ('La materia se ha insertado correctamente.');
		END TRY
		BEGIN CATCH
			PRINT 'Ocurri� un error al insertar la materia.';
			PRINT ERROR_MESSAGE();
		END CATCH
	END;
	GO


CREATE OR ALTER PROC usp_ActualizarMaterias @Id_Materia int,
											@Nombre varchar(100)
	AS
BEGIN
    SET NOCOUNT ON; 

    BEGIN TRY
        IF NOT EXISTS (SELECT 1 FROM Materias WHERE Id_Materia = @Id_Materia)
        BEGIN
            RAISERROR ('No se encontr� una materia con el ID especificado.',11,1);
            RETURN;
        END

        UPDATE Materias
        SET
            Nombre = @Nombre
        WHERE Id_Materia = @Id_Materia;
        PRINT 'La materia se ha actualizado correctamente.';
    END TRY
    BEGIN CATCH
        PRINT 'Ocurri� un error al actualizar la materia.';
    END CATCH
END;
GO

--DELETE
CREATE OR ALTER PROCEDURE usp_EliminarMaterias
    @Id_Materia INT
AS
BEGIN
    BEGIN TRY
        -- Inicia una transacci�n para garantizar la atomicidad
        BEGIN TRANSACTION;

        -- Verificar que el registro existe en la tabla Planes_Curriculares
        IF NOT EXISTS (SELECT 1 FROM Materias WHERE Id_Materia = @Id_Materia)
        BEGIN
            RAISERROR('La materia especificada no existe.', 16, 1);
            ROLLBACK TRANSACTION;
            RETURN;
        END 

        DELETE FROM Materias
        WHERE Id_Materia = @Id_Materia;

        COMMIT TRANSACTION;
        PRINT 'La materia ha sido eliminado exitosamente.';
    END TRY
    BEGIN CATCH
        -- Si ocurre un error, deshacer la transacci�n
        ROLLBACK TRANSACTION;

        -- Capturar el error y mostrarlo
        DECLARE @ErrorMessage NVARCHAR(4000);
        DECLARE @ErrorSeverity INT;
        DECLARE @ErrorState INT;

        SELECT @ErrorMessage = ERROR_MESSAGE(),
               @ErrorSeverity = ERROR_SEVERITY(),
               @ErrorState = ERROR_STATE();

        RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState);
    END CATCH
END;

 --=======================================================================================
--4. PROCEDIMIENTOS PARA TABLA DE PLANES CURRICULARES
--INSERT
CREATE OR ALTER PROCEDURE usp_InsertarPlanesCurriculares
    @Id_Carrera varchar(5),
    @Id_Materia int,
    @Cuatrimestre int
AS
BEGIN
    SET NOCOUNT ON;
    
    BEGIN TRY
        INSERT INTO Planes_Curriculares (Id_Carrera, Id_Materia, Cuatrimestre)
        VALUES (@Id_Carrera, @Id_Materia, @Cuatrimestre);

        PRINT 'Inserci�n exitosa en Planes_Curriculares';
    END TRY
    BEGIN CATCH
        PRINT 'Ocurri� un error durante la inserci�n en Planes_Curriculares';
        THROW;
    END CATCH
END;
GO

--UPDATE
CREATE OR ALTER PROCEDURE usp_ActualizarPlanesCurriculares
    @Id_Curricular int,
    @Id_Carrera varchar(5),
    @Id_Materia int,
    @Cuatrimestre int
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY
        UPDATE Planes_Curriculares
        SET 
            Id_Carrera = @Id_Carrera,
            Id_Materia = @Id_Materia,
            Cuatrimestre = @Cuatrimestre
        WHERE Id_Curricular = @Id_Curricular;

        PRINT 'Actualizaci�n exitosa en Planes_Curriculares';
    END TRY
    BEGIN CATCH
        PRINT 'Ocurri� un error durante la actualizaci�n en Planes_Curriculares';
        THROW;
    END CATCH
END;
GO

--DELETE
CREATE OR ALTER PROCEDURE usp_EliminarPlanesCurriculares
    @IdCurricular INT
AS
BEGIN
    BEGIN TRY
        -- Inicia una transacci�n para garantizar la atomicidad
        BEGIN TRANSACTION;

        -- Verificar que el registro existe en la tabla Planes_Curriculares
        IF NOT EXISTS (SELECT 1 FROM Planes_Curriculares WHERE Id_Curricular = @IdCurricular)
        BEGIN
            RAISERROR('El plan curricular especificado no existe.', 16, 1);
            ROLLBACK TRANSACTION;
            RETURN;
        END 

        DELETE FROM Planes_Curriculares
        WHERE Id_Curricular = @IdCurricular;

        COMMIT TRANSACTION;
        PRINT 'El plan curricular ha sido eliminado exitosamente.';
    END TRY
    BEGIN CATCH
        -- Si ocurre un error, deshacer la transacci�n
        ROLLBACK TRANSACTION;

        -- Capturar el error y mostrarlo
        DECLARE @ErrorMessage NVARCHAR(4000);
        DECLARE @ErrorSeverity INT;
        DECLARE @ErrorState INT;

        SELECT @ErrorMessage = ERROR_MESSAGE(),
               @ErrorSeverity = ERROR_SEVERITY(),
               @ErrorState = ERROR_STATE();

        RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState);
    END CATCH
END;

 --=======================================================================================
--5. PROCEDIMIENTOS PARA TABLA DE ESTUDIANTES
-- Recorre a estudiantes que tengan correo y contrase�a null y crea su respectivo correo y contrase�a

CREATE OR ALTER PROCEDURE usp_InsertEstudiante
    @Nombre1 varchar(35),
    @Nombre2 varchar(35),
    @Apellido1 varchar(35),
    @Apellido2 varchar(35),
    @Cedula varchar(30),
    @Fecha_Nacimiento date,
    @Direccion varchar(100),
    @Id_Carrera varchar(5)
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO Estudiantes (Nombre1, Nombre2, Apellido1, Apellido2, Cedula, Fecha_Nacimiento, Direccion, Id_Carrera)
    VALUES (@Nombre1, @Nombre2, @Apellido1, @Apellido2, @Cedula, @Fecha_Nacimiento, @Direccion, @Id_Carrera);
END;
GO

--DELETE
CREATE OR ALTER PROCEDURE usp_EliminarEstudiante 
    @Id_Estudiante INT
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        
        IF NOT EXISTS (SELECT 1 FROM Estudiantes WHERE Id_Estudiante = @Id_Estudiante)
        BEGIN
            RAISERROR('El estudiante no existe.', 16, 1);
            RETURN;
        END

        DELETE FROM Estudiantes
        WHERE Id_Estudiante = @Id_Estudiante;

        PRINT 'Estudiante eliminado correctamente.';
    END TRY
    BEGIN CATCH
        PRINT 'Ocurri� un error al eliminar el estudiante.';
        PRINT ERROR_MESSAGE();
    END CATCH
END;
GO

--UPDATE
CREATE OR ALTER PROCEDURE usp_UpdateEstudiante
    @Id_Estudiante int,
    @Nombre1 varchar(35),
    @Nombre2 varchar(35),
    @Apellido1 varchar(35),
    @Apellido2 varchar(35),
    @Direccion varchar(100),
    @Id_Carrera varchar(5),
    @Estado char
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE Estudiantes
    SET 
        Nombre1 = @Nombre1,
        Nombre2 = @Nombre2,
        Apellido1 = @Apellido1,
        Apellido2 = @Apellido2,
        Direccion = @Direccion,
        Id_Carrera = @Id_Carrera,
        Estado = @Estado
    WHERE Id_Estudiante = @Id_Estudiante;
END;
GO

--=======================================================================================
--6. PROCEDIMIENTOS PARA TABLA DE PROGRESO DE ESTUDIANTES
--INSERT
CREATE OR ALTER PROCEDURE usp_InsertarProgresoEstudiante
    @Id_Estudiante int,
    @Cuatrimestre int,
    @Id_Materia int,
    @Calificacion int = NULL -- Valor opcional, entre 0 y 100
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY
        INSERT INTO Progreso_Estudiantes (Id_Estudiante, Cuatrimestre, Id_Materia, Calificacion)
        VALUES (@Id_Estudiante, @Cuatrimestre, @Id_Materia, @Calificacion);

        PRINT 'Inserci�n exitosa en Progreso_Estudiantes';
    END TRY
    BEGIN CATCH
        PRINT 'Ocurri� un error durante la inserci�n en Progreso_Estudiantes';
        THROW;
    END CATCH
END;
GO

--UPDATE
CREATE OR ALTER PROCEDURE usp_ActualizarProgresoEstudiante
    @Id_Progreso int,
    @Cuatrimestre int,
	@Id_Materia int,
    @Calificacion decimal (3,1)
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY
        -- Verifica si el registro existe antes de intentar actualizarlo
        IF EXISTS (SELECT 1 FROM Progreso_Estudiantes WHERE Id_Progreso = @Id_Progreso)
        BEGIN
            UPDATE Progreso_Estudiantes
            SET 
                Cuatrimestre = @Cuatrimestre,
                Calificacion = @Calificacion,
				Id_Materia = @Id_Materia
            WHERE Id_Progreso = @Id_Progreso;

            PRINT 'El registro con Id_Progreso = ' + CAST(@Id_Progreso AS VARCHAR) + ' ha sido actualizado exitosamente.';
        END
        ELSE
        BEGIN
            PRINT 'El registro con Id_Progreso = ' + CAST(@Id_Progreso AS VARCHAR) + ' no existe.';
        END
    END TRY
    BEGIN CATCH
        PRINT 'Ocurri� un error durante la actualizaci�n.';
        THROW;
    END CATCH
END;
GO


--DELETE

CREATE OR ALTER PROCEDURE usp_EliminarProgresoEstudiante
    @IdProgreso INT
AS
BEGIN
    BEGIN TRY
        -- Inicia una transacci�n para garantizar la atomicidad
        BEGIN TRANSACTION;

        -- Verificar que el registro existe en la tabla Progreso_Estudiantes
        IF NOT EXISTS (SELECT 1 FROM Progreso_Estudiantes WHERE Id_Progreso = @IdProgreso)
        BEGIN
            RAISERROR('El registro especificado no existe en Progreso_Estudiantes.', 16, 1);
            ROLLBACK TRANSACTION;
            RETURN;
        END

        -- Verificar dependencias en la tabla Estudiantes
        IF NOT EXISTS (
            SELECT 1
            FROM Estudiantes
            WHERE Id_Estudiante = (SELECT Id_Estudiante FROM Progreso_Estudiantes WHERE Id_Progreso = @IdProgreso)
        )
        BEGIN
            RAISERROR('El estudiante asociado al registro no existe.', 16, 1);
            ROLLBACK TRANSACTION;
            RETURN;
        END

        -- Verificar dependencias en la tabla Materias
        IF NOT EXISTS (
            SELECT 1
            FROM Materias
            WHERE Id_Materia = (SELECT Id_Materia FROM Progreso_Estudiantes WHERE Id_Progreso = @IdProgreso)
        )
        BEGIN
            RAISERROR('La materia asociada al registro no existe.', 16, 1);
            ROLLBACK TRANSACTION;
            RETURN;
        END

        -- Eliminar el registro de la tabla Progreso_Estudiantes
        DELETE FROM Progreso_Estudiantes
        WHERE Id_Progreso = @IdProgreso;

        -- Confirmar la transacci�n
        COMMIT TRANSACTION;

        PRINT 'El registro en Progreso_Estudiantes ha sido eliminado exitosamente.';
    END TRY
    BEGIN CATCH
        -- Si ocurre un error, deshacer la transacci�n
        ROLLBACK TRANSACTION;

        -- Capturar el error y mostrarlo
        DECLARE @ErrorMessage NVARCHAR(4000);
        DECLARE @ErrorSeverity INT;
        DECLARE @ErrorState INT;

        SELECT @ErrorMessage = ERROR_MESSAGE(),
               @ErrorSeverity = ERROR_SEVERITY(),
               @ErrorState = ERROR_STATE();

        RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState);
    END CATCH
END;
 --=======================================================================================
--7. PROCEDIMIENTOS PARA TABLA DE MATR�CULAS 
--INSERT
CREATE OR ALTER PROC usp_InsertarMatriculas @Id_Estudiante int,
										  @Id_Materia int
	AS
		BEGIN
		 SET NOCOUNT ON;
		 BEGIN TRY
		  
			INSERT INTO Matriculas(Id_Estudiante, Id_Materia)
			VALUES (@Id_Estudiante, @Id_Materia);
			PRINT ('La matr�cula se ha insertado correctamente.');
		END TRY
		BEGIN CATCH
			PRINT 'Ocurri� un error al insertar la matr�cula.';
			PRINT ERROR_MESSAGE();
		END CATCH
	END;
	GO

--UPDATE
CREATE OR ALTER PROC usp_ActualizarMatriculas @Id_Matricula int,
											  @Id_Estudiante int,
										      @Id_Materia int
											
	AS
BEGIN
    SET NOCOUNT ON; 

    BEGIN TRY
        IF NOT EXISTS (SELECT 1 FROM Matriculas WHERE @Id_Matricula = @Id_Matricula)
        BEGIN
            RAISERROR ('No se encontr� una matr�cula con el ID especificado.',11,1);
            RETURN;
        END

        UPDATE Matriculas
        SET
            Id_Estudiante = @Id_Estudiante,
			Id_Materia = @Id_Materia
        WHERE Id_Matricula = @Id_Matricula;
        PRINT 'La matr�cula se ha actualizado correctamente.';
    END TRY
    BEGIN CATCH
        PRINT 'Ocurri� un error al actualizar la materia.';
    END CATCH
END;
GO

--DELETE
CREATE OR ALTER PROCEDURE usp_EliminarMatr�culas
    @Id_Matricula INT
AS
BEGIN
    BEGIN TRY
        -- Inicia una transacci�n para garantizar la atomicidad
        BEGIN TRANSACTION;

        -- Verificar que el registro existe en la tabla Planes_Curriculares
        IF NOT EXISTS (SELECT 1 FROM Matriculas WHERE Id_Matricula = @Id_Matricula)
        BEGIN
            RAISERROR('La matr�cula especificada no existe.', 16, 1);
            ROLLBACK TRANSACTION;
            RETURN;
        END 

        DELETE FROM Matriculas
        WHERE Id_Matricula = @Id_Matricula;

        COMMIT TRANSACTION;
        PRINT 'La matr�cula ha sido eliminada exitosamente.';
    END TRY
    BEGIN CATCH
        -- Si ocurre un error, deshacer la transacci�n
        ROLLBACK TRANSACTION;

        -- Capturar el error y mostrarlo
        DECLARE @ErrorMessage NVARCHAR(4000);
        DECLARE @ErrorSeverity INT;
        DECLARE @ErrorState INT;

        SELECT @ErrorMessage = ERROR_MESSAGE(),
               @ErrorSeverity = ERROR_SEVERITY(),
               @ErrorState = ERROR_STATE();

        RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState);
    END CATCH
END;


 --=======================================================================================
--8. PROCEDIMIENTOS CON CURSOR Y FUNCI�N AGREGADA
CREATE OR ALTER PROCEDURE usp_CrearCorreoContrasena
AS
BEGIN
	DECLARE @id int,
			@nombre varchar(35),
			@apellido varchar(35),
			@correo varchar(100),
			@contrasena varchar(100),
			@numero int

	DECLARE estudiantes_cursor CURSOR 
	FOR SELECT  Id_Estudiante,
				Nombre1, 
				Apellido1
	FROM Estudiantes 
	WHERE Correo is NULL AND Contrasena is NULL
	
	OPEN estudiantes_cursor  
	FETCH NEXT FROM estudiantes_cursor INTO @id, @nombre, @apellido 

	WHILE @@FETCH_STATUS = 0 
		BEGIN
			SET @nombre = LOWER(
    REPLACE(
    REPLACE(
    REPLACE(
    REPLACE(
    REPLACE(@nombre, '�', 'a'), '�', 'e'), '�', 'i'), '�', 'o'), '�', 'u')
);
			SET @apellido = LOWER(
    REPLACE(
    REPLACE(
    REPLACE(
    REPLACE(
    REPLACE(@apellido, '�', 'a'), '�', 'e'), '�', 'i'), '�', 'o'), '�', 'u')
);

			SET @numero = CAST((RAND() * 90000 + 10000) AS INT);
			SET @correo = @nombre + '.' + @apellido + '@itse.ac.pa'
			SET @contrasena = @apellido + CAST(@numero AS VARCHAR(5))

			UPDATE Estudiantes SET Correo = @correo, Contrasena = @contrasena
			WHERE Id_Estudiante= @id

			FETCH NEXT FROM estudiantes_cursor INTO @id, @nombre, @apellido 
		END
	CLOSE estudiantes_cursor  
	DEALLOCATE estudiantes_cursor
END

SELECT * FROM Estudiantes

EXECUTE usp_CrearCorreoContrasena
 --=======================================================================================
--9. PROCEDIMIENTO QUE OBTIENE UNA LISTA DE MATERIAS QUE UN ESTUDIANTE PARTICULAR PUEDE MATRICULAR
CREATE OR ALTER PROCEDURE MateriasMatricular(@id INT)
AS
BEGIN
    DECLARE @cuatrimestre INT;
    DECLARE @materias_cuatrimestre INT;
    DECLARE @materias_aprobadas INT;

    -- Determinar el �ltimo cuatrimestre cursado
    SELECT @cuatrimestre = MAX(Cuatrimestre) 
    FROM Progreso_Estudiantes 
    WHERE Id_Estudiante = @id;

    -- Si no ha cursado nada, asignar cuatrimestre 0
    IF @cuatrimestre IS NULL
        SET @cuatrimestre = 0;

    -- Contar las materias aprobadas del cuatrimestre actual
    SELECT @materias_aprobadas = COUNT(*) 
    FROM Progreso_Estudiantes 
    WHERE Id_Estudiante = @id 
      AND Cuatrimestre = @cuatrimestre 
      AND Estado = 'A';

    -- Contar las materias requeridas para aprobar el cuatrimestre actual
    SELECT @materias_cuatrimestre = COUNT(*) 
    FROM Planes_Curriculares 
    WHERE Cuatrimestre = @cuatrimestre;

    -- Verificar si aprob� todas las materias necesarias para avanzar
    IF @materias_aprobadas = @materias_cuatrimestre
        SET @cuatrimestre = @cuatrimestre + 1; -- Avanzar al siguiente cuatrimestre

    -- Mostrar materias disponibles para matricular, asegurando que no haya intentos previos incompletos
SELECT M.Id_Materia, M.Nombre
FROM Planes_Curriculares AS P
INNER JOIN Materias AS M ON P.Id_Materia = M.Id_Materia
WHERE P.Cuatrimestre = @cuatrimestre
  AND NOT EXISTS (
      SELECT 1 
      FROM Progreso_Estudiantes AS Pr
      WHERE Pr.Id_Estudiante = @id
        AND Pr.Id_Materia = P.Id_Materia
        AND (
            Pr.Estado IS NULL OR Pr.Calificacion IS NULL
            OR Pr.Estado IN ('A', 'C') -- ya aprobada o cursando tambi�n se excluyen
        )
  );

END;

EXECUTE MateriasMatricular 1
--=======================================================================================
--10. PROCEDIMIENTO QUE MATRICULA TODAS LAS MATERIAS QUE UN ESTUDIANTE EN PARTICULAR PUEDA CURSAR
CREATE OR ALTER PROCEDURE MatricularMateriasDisponibles @id INT
AS
BEGIN
    DECLARE @cuatrimestre INT;
    DECLARE @materias_cuatrimestre INT;
    DECLARE @materias_aprobadas INT;
    DECLARE @filas_afectadas INT;

    -- Determinar el �ltimo cuatrimestre cursado
    SELECT @cuatrimestre = MAX(Cuatrimestre) 
    FROM Progreso_Estudiantes 
    WHERE Id_Estudiante = @id;

    -- Si no ha cursado nada, asignar cuatrimestre 0
    IF @cuatrimestre IS NULL
        SET @cuatrimestre = 0;

    -- Contar las materias aprobadas del cuatrimestre actual
    SELECT @materias_aprobadas = COUNT(*) 
    FROM Progreso_Estudiantes 
    WHERE Id_Estudiante = @id 
      AND Cuatrimestre = @cuatrimestre 
      AND Estado = 'A';

    -- Contar las materias requeridas para aprobar el cuatrimestre actual
    SELECT @materias_cuatrimestre = COUNT(*) 
    FROM Planes_Curriculares 
    WHERE Cuatrimestre = @cuatrimestre;

    -- Verificar si aprob� todas las materias necesarias para avanzar
    IF @materias_aprobadas = @materias_cuatrimestre
        SET @cuatrimestre = @cuatrimestre + 1;

    -- Insertar materias disponibles SOLO si NO hay registros en Progreso con NULLs o estados 'A' o 'C'
    INSERT INTO Matriculas(Id_Estudiante, Fecha_Matricula, Id_Materia)
    SELECT @id, GETDATE(), P.Id_Materia
    FROM Planes_Curriculares AS P
    INNER JOIN Materias AS M ON P.Id_Materia = M.Id_Materia
    WHERE P.Cuatrimestre = @cuatrimestre
      AND NOT EXISTS (
          SELECT 1
          FROM Progreso_Estudiantes AS Pr
          WHERE Pr.Id_Estudiante = @id
            AND Pr.Id_Materia = P.Id_Materia
            AND (
                Pr.Estado IS NULL OR Pr.Calificacion IS NULL
                OR Pr.Estado IN ('A', 'C')
            )
      );

END