--======================================================================================
--Authors: Angie De Gracia, Dorothy Dyer, Jos� Trejos y Mayrenis G�mez
--Create date: 07-12-2024 
--Description: Creaci�n de Tabla Bit�cora y Triggers para Diferentes Tablas.
--=======================================================================================

--BIT�CORA Y TRIGGER PARA MATR�CULA
CREATE TABLE BitacoraMatricula(
			Id_Matricula int,
			Id_Estudiante int,
			Id_Materia int,
			Fecha_Matricula date,
			ExeUser varchar (50),
			ExeHost varchar (50),
			ExeDate datetime,
			ExeAccion varchar (10)
);

CREATE TRIGGER trInsertMatricula
	ON Matriculas FOR INSERT
 AS 
	BEGIN
		INSERT INTO BitacoraMatricula(Id_Matricula, Id_Estudiante, Id_Materia, Fecha_Matricula, ExeUser, 
					ExeHost, ExeDate, ExeAccion)
		SELECT Id_Matricula, Id_Estudiante, Id_Materia, Fecha_Matricula,SUSER_SNAME(), 
					HOST_NAME(), GETDATE(), 'Insert'
		FROM INSERTED;
      END
GO

CREATE or ALTER TRIGGER trDeleteMatricula
	ON Matriculas FOR DELETE
 AS 
	BEGIN
		INSERT INTO BitacoraMatricula(Id_Matricula, Id_Estudiante, Id_Materia, Fecha_Matricula, ExeUser, 
					ExeHost, ExeDate, ExeAccion)
		SELECT Id_Matricula, Id_Estudiante, Id_Materia, Fecha_Matricula,SUSER_SNAME(), 
					HOST_NAME(), GETDATE(), 'Delete'
		FROM DELETED;
       END
GO

CREATE or alter TRIGGER trUpdateMatricula
	ON Matriculas FOR UPDATE
AS
	BEGIN
		SET NOCOUNT ON
			INSERT INTO BitacoraMatricula(Id_Matricula, Id_Estudiante, Id_Materia, Fecha_Matricula, ExeUser, 
					ExeHost, ExeDate, ExeAccion)
		SELECT Id_Matricula, Id_Estudiante, Id_Materia, Fecha_Matricula,SUSER_SNAME(), 
					HOST_NAME(), GETDATE(), 'UInsert'
			FROM INSERTED;
			INSERT INTO BitacoraMatricula(Id_Matricula, Id_Estudiante, Id_Materia, Fecha_Matricula, ExeUser, 
					ExeHost, ExeDate, ExeAccion)
		SELECT Id_Matricula, Id_Estudiante, Id_Materia, Fecha_Matricula,SUSER_SNAME(), 
					HOST_NAME(), GETDATE(), 'UDelete'
		    FROM DELETED;
       END
	GO

--=======================================================================================
--BIT�CORA Y TRIGGER PARA ESTUDIANTES
CREATE TABLE Estudiantes_Bitacora (
    Id_Bitacora int NOT NULL PRIMARY KEY IDENTITY(1,1),
    Id_Estudiante int,
    Operacion varchar(15),
    Fecha_Operacion datetime DEFAULT GETDATE(),
	Usuario varchar(25)
);
GO

--INSERT
CREATE TRIGGER trg_Insert_Estudiantes
ON Estudiantes
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO Estudiantes_Bitacora (Id_Estudiante, Operacion, Fecha_Operacion, Usuario)
    SELECT Id_Estudiante, 'INSERT', GETDATE(), SYSTEM_USER
    FROM INSERTED;

END;
GO

--UPDATE
CREATE TRIGGER trg_Update_Estudiantes
ON Estudiantes
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO Estudiantes_Bitacora (Id_Estudiante, Operacion, Fecha_Operacion, Usuario)
    SELECT Id_Estudiante, 'UINSERT', GETDATE(), SYSTEM_USER
    FROM INSERTED;

	INSERT INTO Estudiantes_Bitacora (Id_Estudiante, Operacion, Fecha_Operacion, Usuario)
    SELECT Id_Estudiante, 'UDELETE', GETDATE(), SYSTEM_USER
    FROM DELETED;

END;
GO

--DELETE
CREATE TRIGGER trg_Delete_Estudiantes
ON Estudiantes
AFTER DELETE
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO Estudiantes_Bitacora (Id_Estudiante, Operacion, Fecha_Operacion, Usuario)
    SELECT Id_Estudiante, 'DELETE', GETDATE(), SYSTEM_USER
    FROM DELETED;
END;
GO


--TRIGGER DE PROCESO EN TABLA PROGRESO_ESTUDIANTES
--Cada vez que se agrega una calificacion en progreso_estudiante, verifica que la calificaci�n est� entre 0 y 100
-- Si se cumple esta condici�n, se actualiza el estado de la materia (aprobado, desaprobado, incompleto)
ALTER TRIGGER [dbo].[trg_agregarEstado]
ON [dbo].[Progreso_Estudiantes]
AFTER UPDATE
AS
BEGIN
    PRINT 'Trigger is being executed';

    -- Validar que las calificaciones est�n en el rango permitido
    IF EXISTS (
        SELECT 1
        FROM inserted
        WHERE Calificacion < 0 OR Calificacion > 100
    )
    BEGIN
        RAISERROR ('La nota debe estar entre 0 y 100', 11, 1);
        RETURN;
    END

    -- Actualizar estado SIEMPRE
    UPDATE Progreso_Estudiantes
    SET Estado = 
        CASE 
            WHEN I.Calificacion = 0 THEN 'I' -- Incompleto
            WHEN I.Calificacion < M.Nota_Aprobacion THEN 'D' -- Desaprobado
            WHEN I.Calificacion >= M.Nota_Aprobacion THEN 'A' -- Aprobado
        END
    FROM Progreso_Estudiantes
    INNER JOIN inserted I
        ON Progreso_Estudiantes.Id_Progreso = I.Id_Progreso
    INNER JOIN Materias M
        ON Progreso_Estudiantes.Id_Materia = M.Id_Materia;
END;

--TRIGGER DE PROCESO EN TABLA MATR�CULAS
--Cada vez que se agrega un registro en la tabla matr�culas, se crea un registro en progreso estudiante para agregar una futura calificacion y tener un historial del estudiante
CREATE OR ALTER TRIGGER trg_InsertProgreso 
ON Matriculas
AFTER INSERT
AS 
BEGIN
    INSERT INTO Progreso_Estudiantes (Id_Estudiante, Id_Materia, Cuatrimestre)
    SELECT 
        i.Id_Estudiante, 
        i.Id_Materia,
        Pa.Cuatrimestre
    FROM inserted i
    INNER JOIN Planes_Curriculares Pa ON i.Id_Materia = Pa.Id_Materia
    WHERE EXISTS (
        SELECT 1 
        FROM Matriculas Ma
        WHERE Ma.Id_Estudiante = i.Id_Estudiante AND Ma.Id_Materia = i.Id_Materia
    );  
END;

