--Crear roles y asignar permisos
-- Crear roles
CREATE ROLE Rol_Administrador;
CREATE ROLE Rol_Profesor;
CREATE ROLE Rol_Estudiante;

-- Asignar permisos para el rol administrador




